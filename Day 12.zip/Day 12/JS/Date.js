let myDate = new Date();
console.log(myDate)
console.log(myDate.getTime())
console.log(myDate.getFullYear())
console.log(myDate.getDay())
console.log(myDate.getMinutes())
console.log(myDate.getHours())
console.log(myDate.getSeconds())
