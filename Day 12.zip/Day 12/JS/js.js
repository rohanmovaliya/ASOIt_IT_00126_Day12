var x=20, y=10;
var addition = x+y;
var subtraction = x-y;

document.write("The sum of x and y is " + addition);
document.write("<br>")
document.write("The difference between x and y is " + subtraction);
document.write("<br>")
document.write("I am Successfully run my first javascript");



