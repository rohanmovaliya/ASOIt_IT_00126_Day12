// Primitive Data Type
var Num = 200;
var str = "Rohan Movaliya"
var bool = true;

document.write("<br>",Num);
document.write("<br>",str);
document.write("<br>",bool);

document.write("<br>", typeof(Num));
document.write("<br>", typeof(str));
document.write("<br>", typeof(bool));

// Non Primitive Data Type

var arr = ["Payal", "Rohan", "Dhruvil", "Kevin"];
document.write("<br>", typeof(arr));
document.write("<br>",arr[0]);
document.write("<br>",arr[1]);
document.write("<br>",arr[2]);
document.write("<br>",arr[3]);

var object = {"Name":"Rohan","age":18,"city": "Rafaliya"};
document.write("<br>", typeof(object));
document.write("<br>",object.city);









